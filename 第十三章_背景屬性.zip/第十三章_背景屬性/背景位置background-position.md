# 背景位置 background-position

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-position` 用來控制背景圖片在元素背景區域中的位置。它通常會搭配 `background-image` 和 `background-repeat: no-repeat;` 使用，讓背景圖片出現在指定方向或指定座標。

學這個屬性時，重點不是只背 `left`、`top`、`center`，而是要分清楚「水平方向」和「垂直方向」如何被指定。不同寫法的判斷規則不完全一樣，尤其是方位名詞和數值混用時，需要看值的類型與順序。

## 關鍵字

- 主題：背景位置
- 英文：`background-position`
- 常見值：`left`、`right`、`top`、`bottom`、`center`、`px`、`%`
- 相關屬性：`background-image`、`background-repeat`
- 常見搜尋：CSS 背景圖片位置、background position、背景圖置中、背景圖靠右
- 易混淆：兩個方位名詞順序通常可互換；數值寫法通常是先水平、再垂直

## 建議回查情境

- 當你想讓背景圖片靠左、靠右、置中或靠上時
- 當你想用精確座標控制背景圖片位置時
- 當你忘記 `background-position: right;` 省略的另一個方向是什麼時
- 當你分不清 `20px center` 和 `center 20px` 的差異時

## 30 秒複習入口

- `background-position` 控制背景圖片在背景區域中的位置。
- 基本概念是先判斷水平方向，再判斷垂直方向。
- 兩個值都是方位名詞時，像 `left top` 和 `top left` 通常等價。
- 兩個值都是數值時，第一個是 X 軸位置，第二個是 Y 軸位置。
- 只寫一個方位名詞時，另一個方向通常默認為 `center`。
- 只寫一個數值時，該數值代表 X 軸位置，Y 軸默認為 `center`。

## 速查區

### 基本語法

```css
background-position: 水平方向位置 垂直方向位置;
```

也可以理解成：

```css
background-position: x y;
```

### 常見寫法

| 寫法 | 意義 |
| --- | --- |
| `left top` | 背景圖靠左上 |
| `top left` | 背景圖靠左上，與 `left top` 等價 |
| `right` | 水平靠右，垂直置中 |
| `top` | 垂直靠上，水平置中 |
| `center` | 水平與垂直都置中 |
| `70px 50px` | X 軸 70px，Y 軸 50px |
| `20px center` | X 軸 20px，Y 軸置中 |
| `center 20px` | X 軸置中，Y 軸 20px |

### 常見錯誤

- 以為 `background-position` 會移動元素本身；它只移動背景圖片。
- 忘記背景圖片預設會平鋪，導致位置變化不明顯；觀察位置時通常要先加 `background-repeat: no-repeat;`。
- 把所有「方位名詞 + 數值」都簡化成第一個值一定是 X、第二個值一定是 Y。這只適合部分常見寫法，遇到 `top`、`bottom`、`left`、`right` 搭配偏移量時要更精確判斷。

## 正文

### 1. `background-position` 是什麼

`background-position` 屬性可以改變背景圖片在背景區域中的位置。

![背景位置示意圖](./images/image_1777874064791_66658a1c.png)

基本寫法：

```css
background-position: x y;
background-position: 水平方向位置 垂直方向位置;
```

在實作中，通常會搭配背景圖片與不平鋪設定：

```css
div {
  width: 300px;
  height: 300px;
  background-color: pink;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-position: right center;
}
```

```html
<div></div>
```

這段程式會讓背景圖片在 `div` 中水平靠右、垂直置中。

> 範例中的 `logo.png` 是示意圖片路徑；實作時要換成專案中實際存在的圖片。

### 2. 參數是方位名詞

方位名詞包含：

- 水平方向：`left`、`center`、`right`
- 垂直方向：`top`、`center`、`bottom`

如果指定的兩個值都是方位名詞，兩個值的前後順序通常不影響結果。

```css
background-position: left top;
background-position: top left;
```

上面兩種寫法都表示背景圖片靠左上。

如果只指定一個方位名詞，另一個方向會默認為 `center`。

```css
background-position: right;
```

這代表：

- 水平方向：靠右
- 垂直方向：置中

```css
background-position: top;
```

這代表：

- 垂直方向：靠上
- 水平方向：置中

完整範例：

```css
div {
  width: 300px;
  height: 300px;
  background-color: pink;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-position: top;
}
```

### 3. 參數是精確單位

如果兩個參數都是精確座標或百分比，第一個值代表 X 軸位置，第二個值代表 Y 軸位置。

```css
background-position: 70px 50px;
```

這代表：

- X 軸：距離左側 `70px`
- Y 軸：距離上方 `50px`

範例：

```css
div {
  width: 300px;
  height: 300px;
  background-color: pink;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-position: 70px 50px;
}
```

如果只指定一個數值，這個數值代表 X 軸位置，Y 軸默認為 `center`。

```css
background-position: 70px;
```

這等價於：

```css
background-position: 70px center;
```

### 4. 參數是方位名詞和數值混合

方位名詞和數值混合時，要先看寫法是否能清楚對應水平方向與垂直方向。

最常見、最容易理解的寫法是：

```css
background-position: 20px center;
```

這代表：

- X 軸：`20px`
- Y 軸：置中

```css
background-position: center 20px;
```

這代表：

- X 軸：置中
- Y 軸：`20px`

範例：

```css
div {
  width: 300px;
  height: 300px;
  background-color: pink;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-position: center 20px;
}
```

這段程式會讓背景圖片水平置中，並在垂直方向距離上方 `20px`。

### 5. 背景位置只影響背景圖片

`background-position` 不會移動元素本身，也不會移動元素裡面的文字或子元素。

它只控制背景圖片在背景區域中的位置。

因此，如果要移動盒子本身，應該使用布局相關屬性，例如 `margin`、`position`、Flex 或 Grid；如果只是要移動背景圖片，才使用 `background-position`。

## 自測問題

1. `background-position` 控制的是元素本身，還是元素的背景圖片？
2. `background-position: right;` 省略的另一個方向是什麼？
3. `background-position: top;` 省略的另一個方向是什麼？
4. `background-position: 70px 50px;` 中，哪個是 X 軸？哪個是 Y 軸？
5. `background-position: center 20px;` 代表什麼？

## 延伸閱讀

- 下一篇：[背景圖像固定 background-attachment](./背景圖像固定background-attachment.md)
- 前置知識：[背景圖片 background-image](./背景圖片background-image.md)
- 前置知識：[背景平鋪 background-repeat](./背景平舖background-repeat.md)
