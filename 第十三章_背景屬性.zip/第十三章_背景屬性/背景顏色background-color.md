# 背景顏色 background-color

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-color` 用來設定元素的背景顏色。它控制的是盒子的背景視覺效果，不會影響盒子的尺寸，也不會影響盒子裡面的文字內容。

背景顏色常用來幫助觀察盒子的大小與位置。做版面布局時，先替區塊加上臨時背景色，可以更容易看出元素實際佔據的範圍。

## 關鍵字

- 主題：背景顏色
- 英文：`background-color`
- 相關值：`transparent`、`rgba()`、alpha 透明度
- 常見搜尋：CSS 背景色、CSS 半透明背景、background-color transparent、rgba alpha
- 易混淆：背景半透明不等於整個元素透明；`opacity` 會影響內容，`rgba()` 背景色不會影響內容

## 建議回查情境

- 當你想替盒子設定背景色時
- 當你想確認背景色的預設值是不是透明時
- 當你想做半透明背景，但不想讓文字跟著透明時
- 當你想分辨 `background-color: rgba()` 和 `opacity` 的差異時

## 30 秒複習入口

- `background-color` 定義元素的背景顏色。
- 背景色的預設值是 `transparent`，也就是透明。
- 背景色不會撐開盒子，只是讓盒子的範圍更容易被看見。
- 半透明背景可以用 `rgba()`，最後一個參數是 alpha 透明度，範圍是 `0` 到 `1`。
- 使用 `rgba()` 設定背景半透明時，盒子裡面的文字不會跟著透明。

## 速查區

### 基本語法

```css
background-color: 顏色值;
```

常見寫法：

```css
background-color: pink;
background-color: transparent;
background-color: rgba(0, 0, 0, .3);
```

### `transparent`

`transparent` 表示透明。一般情況下，元素背景色的預設值就是 `transparent`。

```css
div {
  background-color: transparent;
}
```

### 半透明背景

半透明背景可以使用 `rgba()`：

```css
background-color: rgba(0, 0, 0, 0.3);
```

`rgba()` 的前 3 個參數是紅、綠、藍，最後一個參數是 alpha 透明度：

- `0`：完全透明
- `1`：完全不透明
- `0.3` 或 `.3`：30% 不透明度

`0.3` 前面的 `0` 可以省略：

```css
background-color: rgba(0, 0, 0, .3);
```

也可以使用 `background` 簡寫：

```css
background: rgba(0, 0, 0, .3);
```

### 常見錯誤

- 誤寫成 `background(0, 0, 0, .3);`。這不是有效 CSS，正確寫法要有屬性名稱與 `rgba()`。
- 想讓背景半透明時使用 `opacity`，結果文字也一起變透明。
- 忘記背景顏色只是視覺效果，不會改變盒子的寬高。

## 正文

### 1. `background-color` 是什麼

`background-color` 屬性用來定義元素的背景顏色。

```css
div {
  width: 200px;
  height: 200px;
  background-color: pink;
}
```

```html
<div></div>
```

這段程式會建立一個寬高都是 `200px` 的 `div`，並把它的背景色設定成粉紅色。

### 2. 背景色的預設值是透明

一般情況下，元素的背景顏色預設是 `transparent`。

也就是說，如果沒有替元素設定背景色，它的背景會是透明的，可以看到後方或父層的背景。

你也可以手動指定透明背景：

```css
div {
  background-color: transparent;
}
```

### 3. 背景色不會影響盒子尺寸

背景顏色只會改變盒子的視覺呈現，不會撐開盒子，也不會改變盒模型大小。

因此，下面這段程式中，真正決定盒子大小的是 `width` 和 `height`：

```css
div {
  width: 200px;
  height: 200px;
  background-color: pink;
}
```

背景色的作用是讓盒子的範圍更容易看見。實作版面時，常會先替容器加上背景色，方便觀察布局是否正確。

### 4. 背景色半透明

如果想讓盒子的背景半透明，可以使用 `rgba()`：

```css
div {
  width: 300px;
  height: 300px;
  background-color: rgba(0, 0, 0, .3);
}
```

```html
<div>隱形的翅膀</div>
```

這裡的 `.3` 等同於 `0.3`，代表 alpha 透明度是 `0.3`。

背景半透明只會影響背景顏色，不會影響盒子裡面的文字內容。所以上例中的文字仍然會維持自己的顏色與不透明度。

### 5. `rgba()` 和 `opacity` 的差異

如果只想讓背景半透明，應該優先使用 `rgba()` 或其他支援 alpha 的顏色寫法。

```css
div {
  background-color: rgba(0, 0, 0, .3);
}
```

如果使用 `opacity`，整個元素都會變透明，包含背景、文字與子元素。

```css
div {
  opacity: .3;
}
```

因此：

- 只讓背景半透明：用 `background-color: rgba(...)`
- 讓整個元素一起透明：用 `opacity`

## 自測問題

1. `background-color` 的作用是什麼？
2. 背景顏色的預設值是什麼？
3. 為什麼背景顏色不會撐開盒子？
4. `rgba(0, 0, 0, .3)` 中的 `.3` 代表什麼？
5. `background-color: rgba(...)` 和 `opacity` 有什麼差異？

## 延伸閱讀

- 下一篇：[背景圖片 background-image](./背景圖片background-image.md)
- 相關主題：[背景平鋪 background-repeat](./背景平舖background-repeat.md)
