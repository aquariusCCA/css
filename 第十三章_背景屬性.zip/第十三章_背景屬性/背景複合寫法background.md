# 背景複合寫法 background

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background` 是背景屬性的複合寫法，可以把背景顏色、背景圖片、背景平鋪、背景圖像固定與背景位置寫在同一個屬性中。

使用複合寫法可以讓程式碼更短，但也要注意：`background` 是 shorthand，會重設沒有寫出的背景子屬性。適合在一次設定完整背景時使用；如果只是要修改其中一個背景細節，使用對應的單一屬性通常更清楚。

## 關鍵字

- 主題：背景複合寫法
- 英文：`background`
- 相關屬性：`background-color`、`background-image`、`background-repeat`、`background-attachment`、`background-position`
- 常見搜尋：CSS background 簡寫、background shorthand、背景屬性合併寫法
- 易混淆：`background` 不是只追加設定，它會重設相關背景子屬性

## 建議回查情境

- 當你想把多個背景屬性合併成一行時
- 當你想確認 `background` 簡寫可以包含哪些值時
- 當你改了 `background` 後，發現原本的背景位置或平鋪設定不見時
- 當你想判斷該用複合寫法還是單一背景屬性時

## 30 秒複習入口

- `background` 是背景相關屬性的複合寫法。
- 常見寫法可以包含：背景顏色、背景圖片、背景平鋪、背景圖像固定、背景圖片位置。
- 範例：`background: black url("./images/bg.jpg") no-repeat fixed center top;`
- 如果要一次設定完整背景，複合寫法很方便。
- 如果只想改其中一個背景設定，要小心 `background` 會重設其他未寫出的背景子屬性。

## 速查區

### 常見語法

```css
background: 背景顏色 背景圖片地址 背景平鋪 背景圖像滾動 背景圖片位置;
```

範例：

```css
background: transparent url("./images/bg.jpg") repeat-y fixed top;
```

更完整的範例：

```css
body {
  background: black url("./images/bg.jpg") no-repeat fixed center top;
}
```

### 對應到的單一屬性

| 複合寫法中的值 | 對應屬性 | 說明 |
| --- | --- | --- |
| `black` | `background-color` | 背景顏色 |
| `url("./images/bg.jpg")` | `background-image` | 背景圖片 |
| `no-repeat` | `background-repeat` | 背景圖片不平鋪 |
| `fixed` | `background-attachment` | 背景圖片固定 |
| `center top` | `background-position` | 背景圖片水平置中、垂直靠上 |

### 常見錯誤

- 以為 `background` 只會改自己寫到的部分，忽略它會重設背景相關子屬性。
- 只想改背景顏色，卻寫 `background: red;`，導致原本的背景圖片、平鋪、位置等設定被重設。
- 簡寫塞太多值，反而讓讀者不容易看出每個值對應哪個背景屬性。

## 正文

### 1. 為什麼需要 `background` 複合寫法

為了簡化背景屬性的程式碼，可以把多個背景設定合併到同一個 `background` 屬性中。

原本分開寫可能是：

```css
body {
  background-color: black;
  background-image: url("./images/bg.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center top;
}
```

可以改成：

```css
body {
  background: black url("./images/bg.jpg") no-repeat fixed center top;
}
```

兩者都在描述同一組背景效果：黑色背景、背景圖片不重複、背景固定，並且位置在水平置中、垂直靠上。

### 2. 複合寫法包含哪些背景屬性

這份筆記使用入門階段最常見的一組背景簡寫：

```css
background: 背景顏色 背景圖片地址 背景平鋪 背景圖像滾動 背景圖片位置;
```

例如：

```css
background: transparent url("./images/bg.jpg") repeat-y fixed top;
```

可以拆成：

```css
background-color: transparent;
background-image: url("./images/bg.jpg");
background-repeat: repeat-y;
background-attachment: fixed;
background-position: top;
```

### 3. 完整範例

```css
body {
  min-height: 200vh;
  background: black url("./images/bg.jpg") no-repeat fixed center top;
  color: #fff;
  font-size: 20px;
}
```

```html
<body>
  <p>向下滾動頁面，觀察背景圖片是否固定。</p>
  <p>背景使用複合寫法一次設定顏色、圖片、平鋪、固定與位置。</p>
  <p>如果要替換圖片路徑，請改成專案中實際存在的圖片。</p>
</body>
```

原始筆記中使用大量重複段落製造頁面高度；整理後改用 `min-height: 200vh;` 表示同樣目的，讓範例更容易閱讀。

### 4. 什麼時候適合使用複合寫法

適合使用 `background` 的情況：

- 一次設定完整背景效果
- 寫頁面或區塊背景圖
- 確定要重設該元素的背景相關設定

比較適合使用單一屬性的情況：

- 只想改背景顏色
- 只想調整背景位置
- 只想取消背景平鋪
- 不想影響原本已設定好的其他背景屬性

例如，如果只想改背景顏色，這樣比較安全：

```css
div {
  background-color: red;
}
```

不要在不確定的情況下直接寫：

```css
div {
  background: red;
}
```

因為 `background: red;` 會把其他背景相關設定一起重設。

### 5. 複合寫法不是越短越好

複合寫法的優點是精簡，但可讀性仍然重要。

如果一行 `background` 裡面塞了很多值，而讀者很難判斷每個值代表什麼，可以拆回單一屬性。學習階段尤其建議先理解每個背景子屬性，再使用複合寫法。

## 自測問題

1. `background` 複合寫法可以合併哪些常見背景屬性？
2. `background: black url("./images/bg.jpg") no-repeat fixed center top;` 中，`fixed` 對應哪個單一屬性？
3. 為什麼只想改背景顏色時，不一定適合寫 `background: red;`？
4. 什麼情況下適合使用 `background` 複合寫法？
5. 如果一行簡寫太難讀，應該怎麼處理？

## 延伸閱讀

- 下一篇：[img 標籤和背景圖片的區別](./img標籤和背景圖片的區別.md)
- 前置知識：[背景顏色 background-color](./背景顏色background-color.md)
- 前置知識：[背景圖片 background-image](./背景圖片background-image.md)
- 前置知識：[背景平鋪 background-repeat](./背景平舖background-repeat.md)
- 前置知識：[背景位置 background-position](./背景位置background-position.md)
- 前置知識：[背景圖像固定 background-attachment](./背景圖像固定background-attachment.md)
