# img 標籤和背景圖片的區別

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

在網頁中顯示圖片時，常見做法有兩種：使用 HTML 的 `<img>` 標籤，或使用 CSS 的 `background-image`。兩者都能讓畫面出現圖片，但用途完全不同。

判斷時不要只看「能不能顯示圖片」，而要先問：這張圖片是不是頁面內容的一部分？如果圖片本身有資訊、語意或需要被讀者理解，通常用 `<img>`；如果只是裝飾、背景、氛圍或視覺效果，通常用 `background-image`。

## 關鍵字

- 主題：`img` 與背景圖片差異
- 英文：`img`、`background-image`
- 相關概念：內容圖片、裝飾圖片、語意、`alt`、盒子尺寸
- 常見搜尋：img 和 background-image 差異、CSS 背景圖片和 img、內容圖片和裝飾圖片
- 易混淆：`img` 是 HTML 內容；`background-image` 是 CSS 視覺樣式

## 建議回查情境

- 當你不知道某張圖片該用 `<img>` 還是 `background-image` 時
- 當圖片沒有顯示，想確認是不是背景圖沒有盒子尺寸時
- 當你想分辨「內容圖片」和「裝飾圖片」時
- 當你想確認圖片是否需要 `alt` 文字時

## 30 秒複習入口

- 重要、有語意、屬於內容的圖片，用 `<img>`。
- 裝飾性、不影響內容理解的圖片，用 `background-image`。
- `<img>` 是 HTML 標籤，不設定寬高也會依圖片原始尺寸顯示。
- `background-image` 是 CSS 背景效果，不會撐開元素，需要元素本身有尺寸或內容。
- `<img>` 可以寫 `alt`，能讓搜尋引擎與輔助工具理解圖片用途；背景圖片通常不承載內容語意。

## 速查區

### 一句話判斷

如果拿掉圖片後，頁面內容會變得不完整，用 `<img>`。  
如果拿掉圖片後，只是少了裝飾或視覺效果，用 `background-image`。

### 對比表

| 比較項目 | `<img>` | `background-image` |
| --- | --- | --- |
| 本質 | HTML 內容 | CSS 樣式 |
| 適合圖片 | 內容圖片、商品圖、文章插圖、重要 logo | 裝飾圖、背景圖、紋理、氛圍圖 |
| 是否有語意 | 有，可以搭配 `alt` | 通常沒有內容語意 |
| 是否會撐開空間 | 會依圖片原始尺寸或設定尺寸顯示 | 不會撐開元素 |
| 控制方式 | 用 HTML 屬性與 CSS 控制元素 | 用背景相關 CSS 屬性控制 |
| 圖片載入失敗時 | 可顯示 `alt` 文字 | 通常只是不顯示背景 |

### 常見錯誤

- 把有內容意義的圖片做成背景圖，導致輔助工具與搜尋引擎不容易理解。
- 使用 `background-image` 但沒有設定盒子寬高或內容，導致圖片看不到。
- 為了方便控制位置，把所有圖片都改成背景圖，犧牲語意與可訪問性。

## 正文

### 1. 兩種顯示圖片的方法

需求：在網頁中展示一張圖片。

方法一：直接使用 `<img>` 標籤。

```html
<img src="./images/product.jpg" alt="產品照片">
```

`<img>` 是 HTML 內容標籤。不設定寬高時，圖片會依原始尺寸顯示。

方法二：使用元素加上背景圖片。

```html
<div class="banner"></div>
```

```css
.banner {
  width: 600px;
  height: 240px;
  background-image: url("./images/banner.jpg");
  background-repeat: no-repeat;
  background-position: center;
}
```

`background-image` 是 CSS 樣式。背景圖片不會撐開元素，所以通常需要設定元素寬高、內容或內距。

### 2. 什麼時候用 `<img>`

當圖片本身是頁面內容的一部分時，用 `<img>`。

常見情境：

- 商品圖片
- 使用者頭像
- 文章插圖
- 圖表、流程圖、截圖
- 需要被理解的 logo 或品牌圖片

這類圖片通常需要 `alt` 文字：

```html
<img src="./images/chart.png" alt="2026 年第一季銷售趨勢圖">
```

`alt` 可以在圖片載入失敗時提供替代文字，也能幫助輔助工具理解圖片內容。

### 3. 什麼時候用 `background-image`

當圖片只是視覺裝飾，不影響內容理解時，用 `background-image`。

常見情境：

- 背景大圖
- 裝飾性 icon
- 紋理或圖案
- 卡片或區塊的氛圍背景
- 不需要被讀者單獨理解的視覺效果

例如：

```css
.hero {
  min-height: 360px;
  background-image: url("./images/hero-bg.jpg");
  background-repeat: no-repeat;
  background-position: center;
}
```

這種背景圖主要負責畫面氛圍，不是頁面正文要傳達的資訊。

### 4. 盒子尺寸差異

`<img>` 不設定寬高時，會依圖片原始尺寸顯示。

```html
<img src="./images/logo.png" alt="網站 Logo">
```

背景圖片不會撐開元素。

```css
.logo {
  background-image: url("./images/logo.png");
}
```

上面這段可能看不到背景圖，因為 `.logo` 沒有寬高，也沒有內容撐開空間。

要讓背景圖可見，通常要提供元素尺寸：

```css
.logo {
  width: 120px;
  height: 40px;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
}
```

### 5. 判斷流程

選擇 `<img>` 或 `background-image` 時，可以照這個順序判斷：

1. 這張圖片是否是內容的一部分？
2. 使用者是否需要理解這張圖片傳達的資訊？
3. 圖片是否需要 `alt` 替代文字？
4. 圖片拿掉後，頁面內容是否會變得不完整？

如果答案多半是「是」，使用 `<img>`。

如果圖片只是裝飾，拿掉後不影響內容理解，使用 `background-image`。

## 自測問題

1. 為什麼有語意的圖片應該優先使用 `<img>`？
2. 為什麼 `background-image` 不會自己撐開盒子？
3. 如果一張圖片只是裝飾性的背景，應該使用 `<img>` 還是 `background-image`？
4. 商品圖片通常應該使用哪一種寫法？為什麼？
5. 如果拿掉圖片後頁面內容仍然完整，這通常代表圖片偏向內容還是裝飾？

## 延伸閱讀

- 下一篇：[設置背景圖的原點 background-origin](./設置背景圖的原點background-origin.md)
- 相關主題：[背景圖片 background-image](./背景圖片background-image.md)
- 相關主題：[背景複合寫法 background](./背景複合寫法background.md)
