# 背景圖片 background-image

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-image` 用來替元素設定背景圖片。它常用在裝飾性圖片、logo、區塊背景圖或大尺寸頁面背景。

背景圖片和一般 `<img>` 不同：它是盒子的背景效果，不會自己撐開盒子，也不會取代內容圖片的語意。如果要讓背景圖看得見，元素本身需要有可顯示的寬高或內容空間。

## 關鍵字

- 主題：背景圖片
- 英文：`background-image`
- 相關屬性：`background-repeat`、`background-color`
- 常見搜尋：CSS 背景圖片、CSS background image、背景圖片不顯示
- 易混淆：背景圖片不等於 `<img>` 圖片；背景圖片不會撐開盒子

## 建議回查情境

- 當你想替盒子加上背景圖片時
- 當你忘記 `background-image` 的基本語法時
- 當背景圖片沒有顯示，想確認是否缺少盒子寬高時
- 當你想分辨背景圖片和內容圖片差異時

## 30 秒複習入口

- `background-image` 會把圖片設定成元素的背景。
- 基本語法是 `background-image: url(圖片路徑);`。
- 背景圖片預設會在水平與垂直方向重複平鋪。
- 背景圖片只是一種視覺裝飾，不會撐開盒子的寬高。

## 速查區

### 核心語法

```css
background-image: url(圖片路徑);
```

實務中也可以把路徑加上引號：

```css
background-image: url("./images/logo.png");
```

### 關鍵規則

- `url()` 裡的引號可以省略。
- 若路徑包含空格或特殊字元，使用引號會更穩定。
- 背景圖片預設會重複平鋪，也就是 `background-repeat: repeat;`。
- 背景圖片不會撐開盒子；需要靠 `width`、`height`、內容或 `padding` 讓盒子有可見區域。
- 同一個元素可以同時設定背景顏色與背景圖片；背景圖片會顯示在背景顏色上方。

### 常見錯誤

- 只設定 `background-image`，但盒子沒有寬高或內容，導致看不到背景圖。
- 把裝飾用背景圖片誤當成內容圖片使用。
- 忘記背景圖片預設會平鋪，導致畫面出現重複圖案。

## 正文

### 1. `background-image` 是什麼

`background-image` 屬性用來描述元素的背景圖像。

它在實際開發中常見於：

- logo 或 icon 類的小圖片
- 裝飾性背景
- 大尺寸區塊背景圖
- 頁面背景圖

背景圖片的優點是方便搭配其他背景屬性控制顯示效果，例如是否平鋪、背景位置與背景尺寸。

### 2. 基本寫法

```css
background-image: url(圖片路徑);
```

範例：

```css
div {
  width: 300px;
  height: 300px;
  background-image: url("./images/logo.png");
}
```

```html
<div></div>
```

這段程式會替 `div` 設定一張背景圖片。因為 `div` 已經設定 `width` 和 `height`，所以背景圖片有可顯示的區域。

### 3. 背景圖片不會撐開盒子

背景圖片和背景顏色一樣，都是盒子的背景效果。

如果元素本身沒有內容、寬高或內距，即使設定了 `background-image`，也可能因為盒子沒有可見尺寸而看不到圖片。

```css
div {
  background-image: url("./images/logo.png");
}
```

上面這種寫法不一定能看到背景圖，因為 `div` 沒有設定寬高，也沒有內容撐開它。

### 4. 背景圖片預設會平鋪

背景圖片預設會在水平和垂直方向重複出現。

如果不想讓圖片重複，可以搭配：

```css
background-repeat: no-repeat;
```

背景平鋪的細節可回查：[背景平鋪 background-repeat](./背景平舖background-repeat.md)。

## 自測問題

1. `background-image` 的基本語法是什麼？
2. 為什麼只設定背景圖片，畫面上可能還是看不到圖片？
3. 背景圖片和 `<img>` 圖片在用途上有什麼差異？
4. 背景圖片預設是否會重複平鋪？

## 延伸閱讀

- 上一篇：[背景顏色 background-color](./背景顏色background-color.md)
- 下一篇：[背景平鋪 background-repeat](./背景平舖background-repeat.md)
