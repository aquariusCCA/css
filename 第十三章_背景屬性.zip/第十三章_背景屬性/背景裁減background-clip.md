# 背景裁減 background-clip

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-clip` 用來設定元素背景的繪製範圍，也就是背景要被裁減到 `border-box`、`padding-box`、`content-box`，或文字本身。

它控制的是「背景畫到哪裡為止」，不是控制背景圖片的定位起點。背景圖片的定位起點由 `background-origin` 控制；背景實際可見的裁切範圍才由 `background-clip` 控制。

## 關鍵字

- 主題：背景裁減、背景繪製範圍
- 英文：`background-clip`
- 常見值：`border-box`、`padding-box`、`content-box`、`text`
- 相關概念：盒模型、`background-origin`、`background-position`、漸層文字
- 常見搜尋：CSS background-clip、背景裁切、背景不要畫到 border、漸層文字
- 易混淆：`background-clip` 控制背景裁減範圍；`background-origin` 控制背景圖片定位參考區域

## 建議回查情境

- 當你想讓背景不要延伸到邊框底下時
- 當元素有 `border`、`padding`，但背景顯示範圍和預期不同時
- 當你想把背景限制在內容區域時
- 當你想做漸層文字效果時
- 當你分不清 `background-clip` 和 `background-origin` 時

## 30 秒複習入口

- `background-clip` 決定背景的繪製裁減範圍。
- 預設值是 `border-box`，背景會畫到 border 外緣下方。
- `padding-box` 會把背景裁減到 padding 區域，不畫到 border 下方。
- `content-box` 會把背景裁減到 content 區域。
- `text` 會把背景裁減到文字形狀內，常用來做漸層文字。
- `background-clip: text` 通常要搭配透明文字色，效果才看得出來。

## 速查區

### 基本語法

```css
background-clip: border-box;
background-clip: padding-box;
background-clip: content-box;
background-clip: text;
```

### 常見屬性值

| 值 | 背景繪製範圍 | 說明 |
| --- | --- | --- |
| `border-box` | border 區域 | 預設值，背景會延伸到邊框外緣下方 |
| `padding-box` | padding 區域 | 背景畫到 padding 外緣，不畫到 border 下方 |
| `content-box` | content 區域 | 背景只畫在內容區域 |
| `text` | 文字形狀 | 背景裁減到文字前景形狀內，常用於漸層文字 |

### 和 `background-origin` 的差異

| 屬性 | 控制重點 | 常見用途 |
| --- | --- | --- |
| `background-origin` | 背景圖片定位的參考區域 | 決定 `background-position` 從哪個盒模型區域開始算 |
| `background-clip` | 背景實際繪製的裁減範圍 | 決定背景要畫到 border、padding、content 或文字哪裡為止 |

簡單記法：

- `origin` 看「從哪裡開始定位」。
- `clip` 看「畫到哪裡被裁掉」。

### 漸層文字常用寫法

```css
.title {
  font-size: 36px;
  font-weight: bold;
  background: linear-gradient(45deg, #ff9900, #ff0066);
  color: transparent;
  -webkit-background-clip: text;
  background-clip: text;
}
```

`background-clip: text` 只負責把背景裁減成文字形狀。若文字本身仍有不透明顏色，文字顏色會蓋住背景效果，所以通常會搭配 `color: transparent;`。

### 常見錯誤

- 把 `background-clip` 當成背景圖片定位屬性。背景圖片定位要看 `background-origin` 和 `background-position`。
- 以為 `background-clip: border-box` 會把背景畫在邊框上方。實際上背景仍然在 border 下方。
- 使用 `background-clip: text` 時忘記把文字顏色設成透明，導致看不到漸層背景。
- 拼錯屬性名稱，例如誤寫成 `backgroud-clip`。

## 正文

### 1. `background-clip` 是什麼

`background-clip` 用來決定元素背景的繪製區域。

元素的盒模型可以分成：

- `border-box`：包含 content、padding、border
- `padding-box`：包含 content、padding
- `content-box`：只包含 content

`background-clip` 會決定背景要被限制在哪一個區域內。

```css
.box {
  width: 100px;
  height: 100px;
  padding: 50px;
  border: 20px dotted brown;
  background-color: blueviolet;
  background-clip: border-box;
}
```

這段程式會讓背景畫到 border 外緣下方。因為範例中的 border 是 `dotted`，邊框中間有空隙，所以可以看見背景出現在邊框底下。

### 2. `border-box`

`border-box` 是 `background-clip` 的預設值。

```css
background-clip: border-box;
```

它表示背景會延伸到 border 的外緣。不過背景仍然位在 border 的下方，不會覆蓋邊框本身。

當邊框是不透明實線時，背景在邊框下方不容易被看見；當邊框是 dotted、dashed、半透明或有透明區域時，差異會比較明顯。

### 3. `padding-box`

`padding-box` 會把背景裁減到 padding 區域。

```css
background-clip: padding-box;
```

這表示背景會畫到 padding 的外緣，但不會畫到 border 下方。

當你希望邊框區域不要露出背景色或背景圖時，可以使用 `padding-box`。

### 4. `content-box`

`content-box` 會把背景裁減到 content 區域。

```css
background-clip: content-box;
```

這表示背景只會出現在內容區域，不會延伸到 padding 或 border 區域。

當元素有明顯的 padding，而你想讓背景只貼著內容區域顯示時，可以使用 `content-box`。

### 5. `text`

`text` 會把背景裁減到文字形狀內。

```css
.my-text {
  font-size: 36px;
  font-weight: bold;
  background: linear-gradient(45deg, #ff9900, #ff0066);
  color: transparent;
  -webkit-background-clip: text;
  background-clip: text;
}
```

```html
<div class="my-text">Hello, Background Clip!</div>
```

這段程式會先替文字元素加上漸層背景，再把背景裁減到文字形狀內，最後用透明文字色讓背景露出來。

為了兼容部分瀏覽器，實務上常同時寫：

```css
-webkit-background-clip: text;
background-clip: text;
```

### 6. 完整範例

```css
.box {
  width: 100px;
  height: 100px;
  padding: 50px;
  margin-top: 100px;
  border: 20px dotted brown;
  border-radius: 50%;
  background-color: blueviolet;
  background-clip: border-box;
  /* background-clip: padding-box; */
  /* background-clip: content-box; */
}

.my-text {
  font-size: 36px;
  font-weight: bold;
  background: linear-gradient(45deg, #ff9900, #ff0066);
  color: transparent;
  -webkit-background-clip: text;
  background-clip: text;
}
```

```html
<div class="box"></div>
<div class="my-text">Hello, Background Clip!</div>
```

練習時可以切換 `.box` 裡面的三種值：

```css
background-clip: border-box;
background-clip: padding-box;
background-clip: content-box;
```

觀察重點是背景顏色是否延伸到 border 下方、padding 區域或只剩 content 區域。

## 一句話抓核心

`background-clip` 決定背景「被裁到哪個範圍」，所以它回答的是背景畫到哪裡為止，而不是背景圖片從哪裡開始定位。

## 參考資料

- [MDN：background-clip](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-clip)
- [CSS Backgrounds and Borders Module Level 3：background-clip](https://drafts.csswg.org/css-backgrounds/#background-clip)
