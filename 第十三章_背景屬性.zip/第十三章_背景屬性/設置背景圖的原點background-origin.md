# 設置背景圖的原點 background-origin

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-origin` 用來設定背景圖片定位時的參考區域，也就是背景圖片的定位原點要從 `border-box`、`padding-box` 還是 `content-box` 開始計算。

這個屬性常和 `background-position` 一起理解：`background-position` 決定背景圖片放在哪裡，`background-origin` 決定這個位置要以哪個盒模型區域作為參考。它控制的是背景圖片的定位參考區域，不是控制元素本身的位置。

## 關鍵字

- 主題：背景圖定位原點
- 英文：`background-origin`
- 常見值：`padding-box`、`border-box`、`content-box`
- 相關概念：盒模型、`background-position`、`background-clip`
- 常見搜尋：CSS background-origin、背景圖原點、背景圖片從 padding 開始、背景圖片從 border 開始
- 易混淆：`background-origin` 控制定位參考區域；`background-clip` 控制背景繪製裁切範圍

## 建議回查情境

- 當你想讓背景圖片從 border、padding 或 content 區域開始定位時
- 當你發現 `background-position` 的結果和預期不同時
- 當元素有 `padding` 或 `border`，背景圖片定位需要更精準時
- 當你分不清 `background-origin` 和 `background-clip` 時

## 30 秒複習入口

- `background-origin` 控制背景圖片定位時的參考區域。
- 預設值是 `padding-box`。
- `border-box`：以邊框區域作為背景圖片定位參考。
- `padding-box`：以內距區域作為背景圖片定位參考。
- `content-box`：以內容區域作為背景圖片定位參考。
- 它主要影響背景圖片，不影響背景顏色本身。

## 速查區

### 基本語法

```css
background-origin: padding-box | border-box | content-box;
```

### 屬性值

| 值 | 定位參考區域 | 說明 |
| --- | --- | --- |
| `padding-box` | padding 區域 | 預設值，從 padding 外緣作為背景圖片定位參考 |
| `border-box` | border 區域 | 從 border 外緣作為背景圖片定位參考 |
| `content-box` | content 區域 | 從 content 外緣作為背景圖片定位參考 |

### 常見錯誤

- 把 `background-origin` 理解成「控制背景圖片是否顯示」。它控制的是定位參考區域，不是是否顯示。
- 把 `background-origin` 和 `background-clip` 混在一起。前者偏向定位原點，後者偏向背景繪製裁切範圍。
- 元素沒有 `padding` 或 `border` 時，切換不同值可能不容易看出差異。

## 正文

### 1. `background-origin` 是什麼

`background-origin` 用來設定背景圖片的定位原點。

更精確地說，它決定背景圖片在使用 `background-position` 定位時，要以盒模型中的哪一個區域作為參考。

```css
background-origin: padding-box;
```

預設值是 `padding-box`。

### 2. 三個常見值

#### `padding-box`

`padding-box` 是預設值，表示背景圖片定位時以 padding 區域作為參考。

```css
background-origin: padding-box;
```

#### `border-box`

`border-box` 表示背景圖片定位時以 border 區域作為參考。

```css
background-origin: border-box;
```

當元素有較明顯的邊框時，使用 `border-box` 可以讓背景圖片從包含邊框的區域開始計算位置。

#### `content-box`

`content-box` 表示背景圖片定位時以 content 區域作為參考。

```css
background-origin: content-box;
```

當元素有 padding，而你希望背景圖片只從內容區域開始定位時，可以使用 `content-box`。

### 3. 範例

```css
.box {
  width: 600px;
  height: 500px;
  padding: 50px;
  border: 20px dotted blueviolet;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-origin: border-box;
}
```

```html
<div class="box"></div>
```

這段程式會建立一個有寬高、padding 和 border 的盒子，並把背景圖片的定位參考區域設成 `border-box`。

你可以切換下面幾種值觀察差異：

```css
background-origin: border-box;
background-origin: padding-box;
background-origin: content-box;
```

如果盒子沒有 `padding` 或 `border`，這三個值的視覺差異會比較不明顯。

### 4. 和 `background-position` 的關係

`background-position` 負責指定背景圖片的位置。

```css
background-position: left top;
```

`background-origin` 負責指定這個位置要以哪個區域為起點。

```css
background-origin: content-box;
```

可以把兩者合起來理解：

- `background-position`：圖片放在哪裡
- `background-origin`：以哪個盒模型區域作為定位參考

### 5. 和 `background-clip` 的差異

`background-origin` 和 `background-clip` 很容易混淆。

- `background-origin`：控制背景圖片定位時的參考區域。
- `background-clip`：控制背景繪製到哪個區域為止。

本篇先聚焦 `background-origin`。需要比較裁切範圍時，可再回查 `background-clip`。

## 自測問題

1. `background-origin` 控制的是背景圖片的什麼？
2. `background-origin` 的預設值是什麼？
3. `border-box`、`padding-box`、`content-box` 分別代表哪個定位參考區域？
4. 為什麼沒有 padding 或 border 時，切換 `background-origin` 可能不明顯？
5. `background-origin` 和 `background-clip` 的核心差異是什麼？

## 延伸閱讀

- 前置知識：[背景圖片 background-image](./背景圖片background-image.md)
- 前置知識：[背景位置 background-position](./背景位置background-position.md)
- 相關主題：[背景複合寫法 background](./背景複合寫法background.md)
- 相關主題：[背景裁減 background-clip](./背景裁減background-clip.md)
