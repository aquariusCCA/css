# 背景圖片大小 background-size

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-size` 用來設定背景圖片的顯示尺寸。它不會改變元素本身的寬高，也不會改變圖片檔案的實際尺寸，只會控制背景圖片在元素背景區域中被繪製成多大。

這個屬性常用在三種情境：指定背景圖的固定寬高、讓背景圖等比例覆蓋容器，以及配合二倍圖或響應式區塊控制背景圖顯示效果。

## 關鍵字

- 主題：背景圖片大小
- 英文：`background-size`
- 常見值：`auto`、長度值、百分比、`cover`、`contain`
- 相關概念：背景圖片、背景定位區域、二倍圖、響應式背景圖、`background-position`
- 常見搜尋：CSS background-size、背景圖片等比例縮放、cover contain 差異、二倍圖 background-size
- 易混淆：`cover` 可能裁切圖片；`contain` 可能留下空白或重複平鋪

## 建議回查情境

- 當你想指定背景圖片顯示成固定寬高時
- 當你只寫一個 `background-size` 值，想確認另一個方向怎麼計算時
- 當你想分辨 `cover` 和 `contain` 的差異時
- 當你想讓二倍圖在 CSS 中顯示成正常尺寸時
- 當你想用背景圖片做響應式比例區塊時

## 30 秒複習入口

- `background-size` 控制背景圖片的顯示大小。
- 預設值是 `auto`，通常表示依圖片原始尺寸顯示。
- 寫兩個值時，第一個是寬度，第二個是高度。
- 只寫一個長度或百分比時，這個值代表寬度，高度預設為 `auto`，通常會依圖片比例自動計算。
- `cover` 會等比例放大或縮小背景圖，直到背景區域被完全覆蓋，圖片可能被裁切。
- `contain` 會等比例放大或縮小背景圖，讓整張圖片完整放進背景區域，可能留下空白。

## 速查區

### 基本語法

```css
background-size: 寬度 高度;
```

常見寫法：

```css
background-size: auto;
background-size: 500px 500px;
background-size: 100% 100%;
background-size: 500px;
background-size: 50%;
background-size: cover;
background-size: contain;
```

### 屬性值整理

| 寫法 | 意義 | 注意事項 |
| --- | --- | --- |
| `auto` | 依背景圖片原始尺寸或比例自動計算 | 預設值 |
| `500px 300px` | 指定背景圖片寬度與高度 | 可能讓圖片變形 |
| `500px` | 指定寬度，高度自動 | 通常會保留圖片比例 |
| `50%` | 寬度為背景定位區域的 50%，高度自動 | 百分比不是相對圖片本身 |
| `100% 100%` | 背景圖片寬高都填滿背景區域 | 可能讓圖片被拉伸變形 |
| `cover` | 等比例縮放到完全覆蓋背景區域 | 可能裁切圖片 |
| `contain` | 等比例縮放到完整顯示圖片 | 可能留下空白；若未關閉平鋪，可能重複顯示 |

### `cover` 和 `contain` 對照

| 值 | 優先目標 | 可能結果 | 適合情境 |
| --- | --- | --- | --- |
| `cover` | 容器被完整填滿 | 圖片邊緣可能被裁切 | 卡片封面、滿版背景、需要鋪滿區塊 |
| `contain` | 圖片完整顯示 | 容器可能留白，或在預設平鋪下重複 | Logo、圖示、不能裁切的重要圖片 |

簡單記法：

- `cover`：先保證「容器滿」。
- `contain`：先保證「圖片完整」。

### 常見錯誤

- 以為 `background-size` 會改變元素尺寸。它只改背景圖片顯示大小，不會撐開盒子。
- 用 `100% 100%` 做等比例縮放。這會強制寬高都貼齊容器，圖片比例可能被拉歪。
- 使用 `contain` 時忘記設定 `background-repeat: no-repeat;`，導致圖片在剩餘空間重複平鋪。
- 把響應式比例公式寫反。若圖片寬 `640px`、高 `419px`，比例高度應是 `419 / 640 * 100% = 65.46%`。

## 正文

### 1. `background-size` 是什麼

`background-size` 用來設定背景圖片在元素背景區域中的顯示大小。

```css
background-size: 背景圖片寬度 背景圖片高度;
```

範例：

```css
.box {
  width: 800px;
  height: 800px;
  background-color: pink;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-size: 500px 500px;
}
```

```html
<div class="box"></div>
```

這段程式會建立一個 `800px * 800px` 的盒子，並把背景圖片顯示成 `500px * 500px`。

> 範例中的 `logo.png` 是示意圖片路徑；實作時要換成專案中實際存在的圖片。

### 2. 寫一個值和寫兩個值

`background-size` 可以寫一個值，也可以寫兩個值。

寫兩個值時：

```css
background-size: 500px 300px;
```

第一個值是背景圖片寬度，第二個值是背景圖片高度。

寫一個長度或百分比時：

```css
background-size: 500px;
```

這代表背景圖片寬度是 `500px`，高度省略為 `auto`。在圖片有原始比例的情況下，瀏覽器會依比例自動計算高度。

百分比也可以只寫一個：

```css
background-size: 50%;
```

這代表背景圖片寬度是背景定位區域的 `50%`，高度仍然是 `auto`。

### 3. 使用長度值或百分比

如果你明確知道背景圖片要顯示成多大，可以使用長度值：

```css
background-size: 500px 500px;
```

如果想讓背景圖片尺寸跟著元素大小變化，可以使用百分比：

```css
background-size: 100% 100%;
```

但要注意，`100% 100%` 會讓背景圖片的寬和高都貼齊背景區域。如果圖片比例和容器比例不同，圖片會被拉伸變形。

若想保留圖片比例，通常會優先考慮：

```css
background-size: cover;
```

或：

```css
background-size: contain;
```

### 4. `cover`

`cover` 會讓背景圖片等比例縮放，直到整個背景區域都被覆蓋。

```css
background-size: cover;
```

它的重點是「容器不能露空」。因此，如果圖片比例和容器比例不同，圖片可能會有一部分超出容器並被裁切。

常見搭配：

```css
.box {
  width: 800px;
  height: 400px;
  background-image: url("./images/hero.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
}
```

`background-position: center;` 可以讓裁切更平均，避免圖片只從左上角開始被裁掉。

### 5. `contain`

`contain` 會讓背景圖片等比例縮放，直到整張圖片都能完整放進背景區域。

```css
background-size: contain;
```

它的重點是「圖片要完整」。因此，如果圖片比例和容器比例不同，背景區域可能會留下空白。

常見搭配：

```css
.box {
  width: 800px;
  height: 400px;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}
```

如果沒有設定 `background-repeat: no-repeat;`，圖片在剩餘空間中可能會重複平鋪。

### 6. 二倍圖背景

在高解析度螢幕上，為了讓圖片更清晰，常會準備比 CSS 顯示尺寸更大的圖片。例如畫面上需要一個 `50px * 50px` 的背景圖，但圖片素材可以準備成 `100px * 100px`。

CSS 中再用 `background-size` 把它縮回 `50px * 50px`：

```css
.icon {
  width: 50px;
  height: 50px;
  border: 1px solid #ccc;
  background: url("./images/ldh.jpg") no-repeat;
  background-size: 50px 50px;
}
```

```html
<div class="icon"></div>
```

這樣做的目的不是改變盒子大小，而是讓較高解析度的圖片以較小 CSS 尺寸顯示，減少模糊感。

> 範例中的 `ldh.jpg` 是示意圖片路徑；實作時要換成專案中實際存在的圖片。

### 7. 響應式背景圖片

有時候背景圖片需要跟著容器寬度縮放，同時維持固定比例。常見做法是建立一個有比例高度的區塊，再把背景圖片設定為 `cover`。

現代瀏覽器可以直接使用 `aspect-ratio`：

```css
.figure {
  max-width: 640px;
  aspect-ratio: 640 / 419;
  background: url("./images/ldh.jpg") center / cover no-repeat;
}
```

如果需要使用較傳統的 `padding-top` 比例技巧，公式是：

```css
padding-top = 圖片高度 / 圖片寬度 * 100%
```

例如圖片寬度是 `640px`、高度是 `419px`：

```css
padding-top = 419 / 640 * 100% = 65.46%
```

對應寫法：

```css
.column {
  max-width: 640px;
}

.figure {
  padding-top: 65.46%;
  background: url("./images/ldh.jpg") no-repeat;
  background-size: cover;
  background-position: center;
}
```

```html
<div class="column">
  <div class="figure"></div>
</div>
```

這裡的 `padding-top` 百分比是用來撐出區塊高度。對於一般水平書寫模式，垂直方向 padding 的百分比會相對於包含塊的寬度計算，所以可以用它做出固定寬高比的區塊。

## 一句話抓核心

`background-size` 決定背景圖片「畫多大」；`cover` 保證容器被填滿，`contain` 保證圖片完整顯示。

## 參考資料

- [CSS Backgrounds and Borders Module Level 3：background-size](https://drafts.csswg.org/css-backgrounds/#background-size)
- [CSS Box Model Module Level 4：padding percentage](https://drafts.csswg.org/css-box/#padding-physical)
