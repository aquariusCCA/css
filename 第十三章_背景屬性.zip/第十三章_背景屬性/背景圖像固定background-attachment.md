# 背景圖像固定 background-attachment

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-attachment` 用來設定背景圖片是否會跟著頁面或元素內容一起滾動。

這個屬性常用來做「背景固定」效果：頁面內容向下滾動時，背景圖片看起來停在原地。後續如果搭配大圖、背景位置與內容區塊，就可以做出簡單的視差滾動效果。

## 關鍵字

- 主題：背景圖像固定
- 英文：`background-attachment`
- 常見值：`scroll`、`fixed`
- 相關屬性：`background-image`、`background-repeat`、`background-position`
- 常見搜尋：CSS 背景固定、background attachment fixed、背景圖不跟著滾動、視差滾動
- 易混淆：`scroll` 是跟著頁面滾動；`fixed` 才是固定在視窗中

## 建議回查情境

- 當你想讓背景圖片固定，不跟著頁面內容滾動時
- 當你想確認 `scroll` 和 `fixed` 的差異時
- 當你想做簡單視差滾動效果時
- 當 CSS 註解寫固定背景，但畫面仍跟著滾動時

## 30 秒複習入口

- `background-attachment` 控制背景圖片是否隨頁面滾動。
- `scroll` 是預設效果，背景圖片會隨著元素或頁面一起滾動。
- `fixed` 會讓背景圖片相對於視窗固定，頁面滾動時背景看起來不動。
- 要觀察 `fixed` 效果，頁面通常需要足夠高度可以滾動。
- 想固定背景時，應寫 `background-attachment: fixed;`，不是 `scroll`。

## 速查區

### 基本語法

```css
background-attachment: scroll | fixed;
```

### 常見值

| 值 | 意義 | 使用情境 |
| --- | --- | --- |
| `scroll` | 背景圖片會跟著頁面或元素一起滾動 | 預設值，一般背景圖 |
| `fixed` | 背景圖片相對於視窗固定 | 固定背景、簡單視差效果 |

### 常見錯誤

- 註解寫「固定背景」，但實際設定 `background-attachment: scroll;`。
- 頁面高度不夠，沒有滾動效果，因此看不出 `fixed` 和 `scroll` 的差異。
- 只設定 `background-attachment`，但沒有設定 `background-image`，所以看不到效果。

## 正文

### 1. `background-attachment` 是什麼

`background-attachment` 屬性用來設定背景圖像是否固定，或是否隨著頁面的其餘部分一起滾動。

```css
background-attachment: scroll | fixed;
```

它主要控制背景圖片的滾動方式，不會改變盒子的大小，也不會移動元素內容。

### 2. `scroll`：背景跟著頁面滾動

`scroll` 是常見的預設效果。當頁面滾動時，背景圖片會跟著元素或頁面一起移動。

```css
body {
  background-image: url("./images/bg.jpg");
  background-repeat: no-repeat;
  background-position: center top;
  background-attachment: scroll;
}
```

如果你沒有特別想做固定背景，通常會維持這個預設行為。

### 3. `fixed`：背景固定在視窗中

`fixed` 會讓背景圖片相對於視窗固定。頁面內容滾動時，背景圖片看起來停在原地。

```css
body {
  background-image: url("./images/bg.jpg");
  background-repeat: no-repeat;
  background-position: center top;
  background-attachment: fixed;
}
```

這才是「把背景圖片固定住」的寫法。

> 範例中的 `bg.jpg` 是示意圖片路徑；實作時要換成專案中實際存在的圖片。

### 4. 完整示範

要看出背景固定效果，頁面需要有足夠內容產生滾動。

```css
body {
  min-height: 200vh;
  background-image: url("./images/bg.jpg");
  background-repeat: no-repeat;
  background-position: center top;
  background-attachment: fixed;
  color: #fff;
  font-size: 20px;
}
```

```html
<body>
  <p>向下滾動頁面，觀察背景圖片是否固定。</p>
  <p>如果使用 fixed，背景圖片會停在視窗中。</p>
  <p>如果使用 scroll，背景圖片會跟著頁面一起移動。</p>
</body>
```

原始筆記中用大量重複段落製造頁面高度；整理後改用 `min-height: 200vh;` 表示同樣目的，讓示範更容易閱讀。

### 5. 和視差滾動的關係

`background-attachment: fixed;` 可以製作簡單的背景固定效果。當前景內容滾動、背景停在原地時，視覺上會出現類似視差的感覺。

但真正完整的視差滾動通常還會搭配：

- 大尺寸背景圖
- `background-position`
- 多個內容區塊
- JavaScript 或更細緻的動畫控制

因此，`background-attachment: fixed;` 可以視為簡單視差效果的基礎，不等於所有視差滾動效果的完整做法。

## 自測問題

1. `background-attachment` 控制的是什麼？
2. `scroll` 和 `fixed` 的差異是什麼？
3. 想讓背景圖片固定在視窗中，應該寫哪個值？
4. 為什麼頁面高度不夠時，不容易看出 `fixed` 的效果？
5. `background-attachment` 會不會移動元素裡面的文字內容？

## 延伸閱讀

- 下一篇：[背景複合寫法 background](./背景複合寫法background.md)
- 前置知識：[背景圖片 background-image](./背景圖片background-image.md)
- 前置知識：[背景平鋪 background-repeat](./背景平舖background-repeat.md)
- 前置知識：[背景位置 background-position](./背景位置background-position.md)
