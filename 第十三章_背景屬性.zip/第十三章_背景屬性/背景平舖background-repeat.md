# 背景平鋪 background-repeat

所屬章節：[第13章 背景屬性](./README.md)

## 本節導讀

`background-repeat` 用來控制背景圖片是否重複平鋪，以及沿著哪個方向重複。

當背景圖片比元素盒子小時，瀏覽器預設會讓背景圖片在水平與垂直方向重複出現。若只想顯示一張背景圖，或只想沿著 X 軸、Y 軸重複，就需要設定 `background-repeat`。

## 關鍵字

- 主題：背景平鋪
- 英文：`background-repeat`
- 常見值：`repeat`、`no-repeat`、`repeat-x`、`repeat-y`
- 常見搜尋：CSS 背景圖片重複、background repeat、背景圖片不平鋪
- 易混淆：背景圖片預設會平鋪；背景顏色不需要設定 `background-repeat`

## 建議回查情境

- 當背景圖片一直重複出現時
- 當你想讓背景圖片只顯示一次時
- 當你想讓背景圖片只沿水平方向或垂直方向重複時
- 當你想理解背景圖片和背景顏色的疊放關係時

## 30 秒複習入口

- `background-repeat` 控制背景圖片的重複方式。
- 預設值是 `repeat`，表示水平與垂直方向都會重複。
- `no-repeat` 表示背景圖片只顯示一次。
- `repeat-x` 表示只沿 X 軸水平重複。
- `repeat-y` 表示只沿 Y 軸垂直重複。
- 同一個元素可以同時有背景顏色與背景圖片；背景圖片會顯示在背景顏色上方。

## 速查區

### 基本語法

```css
background-repeat: repeat | no-repeat | repeat-x | repeat-y;
```

### 常見值

| 值 | 效果 | 常見用途 |
| --- | --- | --- |
| `repeat` | 水平與垂直方向都重複 | 預設值，適合紋理或平鋪圖案 |
| `no-repeat` | 不重複，只顯示一次 | logo、icon、單張裝飾圖 |
| `repeat-x` | 只沿 X 軸水平重複 | 水平背景線、橫向紋理 |
| `repeat-y` | 只沿 Y 軸垂直重複 | 垂直背景線、側邊紋理 |

### 常見錯誤

- 忘記背景圖片預設會平鋪，導致同一張小圖重複出現。
- 想控制背景顏色是否重複，但 `background-repeat` 只影響背景圖片。
- 設定 `no-repeat` 後圖片位置不符合預期，這時通常還需要搭配 `background-position`。

## 正文

### 1. `background-repeat` 是什麼

如果需要控制 HTML 元素上的背景圖像是否平鋪，可以使用 `background-repeat` 屬性。

背景圖片比盒子小時，預設會從背景定位點開始重複排列，直到填滿元素的背景區域。

![背景平鋪示意圖](./images/image_1777874064784_6338e9b6.png)

### 2. 基本寫法

```css
background-repeat: repeat | no-repeat | repeat-x | repeat-y;
```

範例：

```css
div {
  width: 900px;
  height: 900px;
  background-color: pink;
  background-image: url("./images/logo.png");
  background-repeat: no-repeat;
}
```

```html
<div></div>
```

這段程式會替 `div` 設定背景顏色與背景圖片，並讓背景圖片只顯示一次，不再重複平鋪。

> 範例中的 `logo.png` 是示意圖片路徑；實作時要換成專案中實際存在的圖片。

### 3. 四種常見平鋪方式

#### `repeat`

`repeat` 是預設值，表示背景圖片會在水平和垂直方向重複。

```css
div {
  background-repeat: repeat;
}
```

#### `no-repeat`

`no-repeat` 表示背景圖片不重複，只顯示一次。

```css
div {
  background-repeat: no-repeat;
}
```

#### `repeat-x`

`repeat-x` 表示背景圖片只沿著 X 軸水平重複。

```css
div {
  background-repeat: repeat-x;
}
```

#### `repeat-y`

`repeat-y` 表示背景圖片只沿著 Y 軸垂直重複。

```css
div {
  background-repeat: repeat-y;
}
```

### 4. 背景圖片與背景顏色的疊放關係

同一個元素可以同時設定背景顏色與背景圖片。

```css
div {
  background-color: pink;
  background-image: url("./images/logo.png");
}
```

背景顏色會先鋪在背景層，背景圖片會顯示在背景顏色上方。若背景圖片本身有透明區域，就能從透明處看到背景顏色。

## 自測問題

1. `background-repeat` 控制的是背景顏色還是背景圖片？
2. `background-repeat` 的預設值是什麼？
3. 如果只想讓背景圖片顯示一次，應該使用哪個值？
4. `repeat-x` 和 `repeat-y` 的差異是什麼？
5. 同一個元素同時設定背景顏色與背景圖片時，哪一個會顯示在上方？

## 延伸閱讀

- 上一篇：[背景圖片 background-image](./背景圖片background-image.md)
- 下一篇：[背景位置 background-position](./背景位置background-position.md)
- 前置知識：[背景顏色 background-color](./背景顏色background-color.md)
